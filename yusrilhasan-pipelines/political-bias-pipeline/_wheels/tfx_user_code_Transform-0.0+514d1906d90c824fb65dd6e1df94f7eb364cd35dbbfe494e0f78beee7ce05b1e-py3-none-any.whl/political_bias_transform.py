import tensorflow as tf
import tensorflow_transform as tft

LABEL_KEY = "bias"
FEATURE_KEY = "text"
def transformed_name(key):
    """Renaming transformed features"""
    return key + "_xf"
def preprocessing_fn(inputs):
    """
    Preprocess input features into transformed features
    
    Args:
        inputs: map from feature keys to raw features.
    
    Return:
        outputs: map from feature keys to transformed features.    
    """
    
    outputs = {}
    
    outputs[transformed_name(FEATURE_KEY)] = tf.strings.lower(inputs[FEATURE_KEY])
    
    # Create vocabulary using compute_and_apply_vocabulary
    labels_vocab = tft.compute_and_apply_vocabulary(
        inputs[LABEL_KEY],
        vocab_filename="labels_vocab",
        default_value=-1
    )
    
    outputs[transformed_name(LABEL_KEY)] = labels_vocab
    
    # outputs[transformed_name(LABEL_KEY)] = tf.one_hot(inputs[LABEL_KEY], depth=5)
    
    return outputs
