import tensorflow as tf
LABEL_KEY = "bias"
FEATURE_KEY = "text"
def transformed_name(key):
    """Renaming transformed features"""
    return key + "_xf"
def preprocessing_fn(inputs):
    """
    Preprocess input features into transformed features
    
    Args:
        inputs: map from feature keys to raw features.
    
    Return:
        outputs: map from feature keys to transformed features.    
    """
    
    outputs = {}
    
    outputs[transformed_name(FEATURE_KEY)] = tf.strings.lower(inputs[FEATURE_KEY])
    
    # Ensure the label tensor has the correct shape
    # Get vocabulary from labels
    labels = inputs[LABEL_KEY]
    labels_vocab = tf.unique(tf.reshape(labels, [-1]))[0]
    
    # Create mapping dictionary
    values = tf.range(tf.size(labels_vocab), dtype=tf.int64)
    values_str = tf.strings.as_string(values)  # Convert to string
    
    # Join labels and values
    mapping = tf.strings.join([
        labels_vocab,
        values_str  # Use string version
    ], separator=' -> ')
    
    # Save mapping
    tf.io.write_file(
        'label_mapping.txt',
        tf.strings.reduce_join(mapping, separator='\n')
    )
    outputs[transformed_name(LABEL_KEY)] = tf.squeeze(encoded_labels, axis=-2)
    # outputs[transformed_name(LABEL_KEY)] = tf.one_hot(inputs[LABEL_KEY], depth=5)
    
    return outputs
