import tensorflow as tf
import tensorflow_transform as tft
import json
from sklearn.preprocessing import LabelEncoder

LABEL_KEY = "bias"
FEATURE_KEY = "text"

def transformed_name(key):
    """Renaming transformed features"""
    return key + "_xf"
def preprocessing_fn(inputs):
    """
    Preprocess input features into transformed features
    
    Args:
        inputs: map from feature keys to raw features.
    
    Return:
        outputs: map from feature keys to transformed features.    
    """
    
    outputs = {}
    
    # Remove unusual characters
    # Remove rows with NA values in either feature or label columns
    cleaned_tensor = tf.strings.regex_replace(inputs[FEATURE_KEY], '[â€”â€™â—]', '')

    feature_is_not_na = tf.not_equal(cleaned_tensor, tf.constant('', dtype=tf.string))
    label_is_not_na = tf.not_equal(inputs[LABEL_KEY], tf.constant('', dtype=tf.string))
    valid_rows = tf.logical_and(feature_is_not_na, label_is_not_na)
    
    # Filter out invalid rows
    filtered_inputs = {key: tf.boolean_mask(tensor, valid_rows) for key, tensor in inputs.items()}

    outputs[transformed_name(FEATURE_KEY)] = tf.strings.lower(filtered_inputs)
    
    # Load the mapping from JSON
    with open('mapping.json', 'r') as f:
        mapping = json.load(f)

    # Create a lookup table for the mapping
    initializer = tf.lookup.KeyValueTensorInitializer(
        keys=tf.constant(list(mapping.keys())),
        values=tf.constant(list(mapping.values())),
        key_dtype=tf.string,
        value_dtype=tf.int32
    )
    table = tf.lookup.StaticHashTable(initializer, default_value=-1)
    
    # Convert the label to int32 and then cast to float32
    label_int = table.lookup(inputs[LABEL_KEY])
    outputs[transformed_name(LABEL_KEY)] = tf.cast(label_int, dtype=tf.float32)
    
    # outputs[transformed_name(LABEL_KEY)] = tf.one_hot(inputs[LABEL_KEY], depth=5)
    
    return outputs
