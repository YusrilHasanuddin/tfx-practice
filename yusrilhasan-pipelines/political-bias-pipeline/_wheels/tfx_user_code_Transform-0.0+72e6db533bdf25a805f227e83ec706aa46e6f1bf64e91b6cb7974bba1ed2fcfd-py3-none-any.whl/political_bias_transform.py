import tensorflow as tf
import tensorflow_transform as tft

LABEL_KEY = "bias"
FEATURE_KEY = "text"
def transformed_name(key):
    """Renaming transformed features"""
    return key + "_xf"
def preprocessing_fn(inputs):
    """
    Preprocess input features into transformed features
    
    Args:
        inputs: map from feature keys to raw features.
    
    Return:
        outputs: map from feature keys to transformed features.    
    """
    
    outputs = {}
    
    outputs[transformed_name(FEATURE_KEY)] = tf.strings.lower(inputs[FEATURE_KEY])
    
    # Load mapping from JSON
    with tf.io.gfile.GFile('mapping.json', 'r') as f:
        mapping = json.load(f)
    
    # Create vocabulary list in order
    vocab = sorted(mapping.keys(), key=lambda x: mapping[x])
    
    # Use compute_and_apply_vocabulary with manual vocab
    indices = tft.compute_and_apply_vocabulary(
        inputs[LABEL_KEY],
        vocab_filename="labels_vocab_mapped",
        vocabulary_list=vocab,
        store_frequency=False,
        num_oov_buckets=1
    )
    
    
    outputs[transformed_name(LABEL_KEY)] = indices
    
    # outputs[transformed_name(LABEL_KEY)] = tf.one_hot(inputs[LABEL_KEY], depth=5)
    
    return outputs
