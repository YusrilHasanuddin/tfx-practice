# filepath: /Users/hasanuddinm/Downloads/dicoding/tfx-practice/setup.py
from setuptools import find_packages, setup

setup(
    name='political_bias_tfx',
    version='0.0.1',
    packages=find_packages(),
    install_requires=[
        'tensorflow',
        'tensorflow-transform',
        'tensorflow-hub',
        'tfx',
        'keras-tuner'
    ],
    entry_points={
        'console_scripts': [
            'tfx_pipeline=political_bias_tfx.main:main',
        ],
    },
)