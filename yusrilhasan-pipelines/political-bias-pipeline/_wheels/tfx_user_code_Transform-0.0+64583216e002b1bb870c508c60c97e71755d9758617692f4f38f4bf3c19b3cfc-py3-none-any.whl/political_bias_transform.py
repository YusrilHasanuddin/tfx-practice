import tensorflow as tf
import tensorflow_transform as tft

LABEL_KEY = "bias"
FEATURE_KEY = "text"
def transformed_name(key):
    """Renaming transformed features"""
    return key + "_xf"
def preprocessing_fn(inputs):
    """
    Preprocess input features into transformed features
    
    Args:
        inputs: map from feature keys to raw features.
    
    Return:
        outputs: map from feature keys to transformed features.    
    """
    
    outputs = {}
    
    outputs[transformed_name(FEATURE_KEY)] = tf.strings.lower(inputs[FEATURE_KEY])
    
    # Get vocabulary with indices mapped to original labels
    labels_vocab, indices = tft.compute_and_apply_vocabulary(
        inputs[LABEL_KEY],
        vocab_filename="labels_vocab_mapped",
        # Store labels and indices in separate files
        store_frequency=False,
        # Add metadata to track original labels
        metadata={'original_labels': inputs[LABEL_KEY]}
    )
    
    # Save mapping to a separate file for reference
    table_keys = tf.cast(tf.range(tf.shape(labels_vocab)[0]), tf.int64)
    mapping = tf.strings.join([
        tf.strings.as_string(table_keys),
        labels_vocab
    ], separator=',')
    
    tf.io.write_file(
        'labels_mapping.txt',
        tf.strings.reduce_join(mapping, separator='\n')
    )
    
    outputs[transformed_name(LABEL_KEY)] = indices
    
    # outputs[transformed_name(LABEL_KEY)] = tf.one_hot(inputs[LABEL_KEY], depth=5)
    
    return outputs
