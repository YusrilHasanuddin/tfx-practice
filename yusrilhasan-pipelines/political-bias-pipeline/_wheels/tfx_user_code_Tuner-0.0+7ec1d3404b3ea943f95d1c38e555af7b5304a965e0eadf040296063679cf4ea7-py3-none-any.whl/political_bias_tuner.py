
from tensorflow.keras import layers
import tensorflow as tf
import tensorflow_transform as tft
import os  
import tensorflow_hub as hub
from tfx.components.trainer.fn_args_utils import FnArgs
import keras_tuner as kt

try:
    # Try the most common import paths
    try:
        from tfx.components.tuner.component import TunerFnResult
    except ImportError:
        try:
            from tfx.extensions.google_cloud_ai_platform.tuner.component import TunerFnResult
        except ImportError:
            try:
                from tfx.v1.components.tuner.component import TunerFnResult
            except ImportError:
                # Define our own if none of the imports work
                class TunerFnResult:
                    def __init__(self, tuner, fit_kwargs):
                        self.tuner = tuner
                        self.fit_kwargs = fit_kwargs
except Exception as e:
    print(f"Error importing TunerFnResult: {e}")
    # Define a basic version if all else fails
    class TunerFnResult:
        def __init__(self, tuner, fit_kwargs):
            self.tuner = tuner
            self.fit_kwargs = fit_kwargs
            
LABEL_KEY = "bias"
FEATURE_KEY = "text"
NUM_CLASSES = 5  # Update this to match your number of categories
# Vocabulary size and number of words in a sequence.
VOCAB_SIZE = 1000
SEQUENCE_LENGTH = 100
embedding_dim=16

 
def transformed_name(key):
    """Renaming transformed features"""
    return key + "_xf"

def gzip_reader_fn(filenames):
    """Loads compressed data"""
    return tf.data.TFRecordDataset(filenames, compression_type='GZIP')

def input_fn(file_pattern, 
             tf_transform_output,
             num_epochs,
             batch_size=64)->tf.data.Dataset:
    """Get post_tranform feature & create batches of data"""
    
    # Get post_transform feature spec
    transform_feature_spec = (
        tf_transform_output.transformed_feature_spec().copy())
    
    # create batches of data
    dataset = tf.data.experimental.make_batched_features_dataset(
        file_pattern=file_pattern,
        batch_size=batch_size,
        features=transform_feature_spec,
        reader=gzip_reader_fn,
        num_epochs=num_epochs,
        label_key=transformed_name(LABEL_KEY))
    return dataset

vectorize_layer = layers.TextVectorization(
    standardize="lower_and_strip_punctuation",
    max_tokens=VOCAB_SIZE,
    output_mode='int',
    output_sequence_length=SEQUENCE_LENGTH)

def model_builder(hp):
    """Build machine learning model without TextVectorization layer"""
    
    # Get preprocessed input directly
    inputs = tf.keras.Input(shape=(1,), name=transformed_name(FEATURE_KEY), dtype=tf.string)
    
    # Use embedding with string input
    # First convert the string into hash buckets
    hash_bucket_size = VOCAB_SIZE
    hashed_text = tf.strings.to_hash_bucket_fast(inputs, hash_bucket_size)
    
    # Reshape to ensure consistent shape - avoiding potential None dimensions
    reshaped_text = tf.reshape(hashed_text, [-1, 1])
    
    # Use a fixed embedding size instead of SEQUENCE_LENGTH which might be causing issues
    word_vectors = tf.keras.layers.Embedding(
        input_dim=VOCAB_SIZE,
        output_dim=embedding_dim
    )(reshaped_text)
    
    # GlobalAveragePooling1D to handle variable length inputs
    x = tf.keras.layers.GlobalAveragePooling1D()(word_vectors)
    
    # Define units with explicit default to avoid None comparison
    units_1 = hp.Int('units_1', min_value=32, max_value=128, step=32, default=64)
    units_2 = hp.Int('units_2', min_value=32, max_value=128, step=32, default=64)
    
    x = tf.keras.layers.Dense(units_1, activation='relu')(x)
    x = tf.keras.layers.Dense(units_2, activation='relu')(x)
    outputs = tf.keras.layers.Dense(NUM_CLASSES, activation='softmax')(x)
    
    model = tf.keras.Model(inputs=inputs, outputs=outputs)
    
    # Use a default learning rate to avoid None comparison
    learning_rate = hp.Choice('learning_rate', values=[1e-2, 1e-3], default=1e-3)
    
    model.compile(
        loss='categorical_crossentropy',
        optimizer=tf.keras.optimizers.Adam(learning_rate),
        metrics=['accuracy']
    )
    
    return model

def tuner_fn(fn_args: FnArgs) -> TunerFnResult:
    """Build the tuner using the KerasTuner API."""
    
    # Get transform output
    tf_transform_output = tft.TFTransformOutput(fn_args.transform_graph_path)
    
    # Create tuner
    tuner = kt.Hyperband(
        model_builder,
        objective='val_accuracy',
        max_epochs=10,
        factor=3,
        directory=fn_args.working_dir,
        project_name='political_bias_tuning'
    )
    
    # Create training dataset
    train_dataset = input_fn(
        file_pattern=fn_args.train_files,
        tf_transform_output=tf_transform_output,
        num_epochs=10,
        batch_size=64
    )
    
    # Create validation dataset
    eval_dataset = input_fn(
        file_pattern=fn_args.eval_files,
        tf_transform_output=tf_transform_output,
        num_epochs=1,
        batch_size=64
    )
    
    return TunerFnResult(
        tuner=tuner,
        fit_kwargs={
            "x": train_dataset,
            "validation_data": eval_dataset,
            "steps_per_epoch": fn_args.train_steps,
            "validation_steps": fn_args.eval_steps
        }
    )
