import tensorflow as tf
import tensorflow_transform as tft
import json

LABEL_KEY = "bias"
FEATURE_KEY = "text"
def transformed_name(key):
    """Renaming transformed features"""
    return key + "_xf"
def preprocessing_fn(inputs):
    """
    Preprocess input features into transformed features
    
    Args:
        inputs: map from feature keys to raw features.
    
    Return:
        outputs: map from feature keys to transformed features.    
    """
    
    outputs = {}
    
    outputs[transformed_name(FEATURE_KEY)] = tf.strings.lower(inputs[FEATURE_KEY])
    
    # Load mapping from JSON
    with tf.io.gfile.GFile('mapping.json', 'r') as f:
        mapping = json.load(f)
    
    print(mapping)
    print(mapping.keys())
    print(mapping.values())
    # Create string keys and integer values explicitly 
    keys = tf.constant([str(k) for k in mapping.keys()], dtype=tf.string)
    values = tf.constant([str(v) for v in mapping.values()], dtype=tf.string)
    
    table = tf.lookup.StaticHashTable(
        tf.lookup.KeyValueTensorInitializer(
            keys=keys,
            values=values
        ),
        default_value=-1
    )
    
    outputs[transformed_name(LABEL_KEY)] = table.lookup(inputs[LABEL_KEY])
    
    # outputs[transformed_name(LABEL_KEY)] = tf.one_hot(inputs[LABEL_KEY], depth=5)
    
    return outputs
