import tensorflow as tf
import tensorflow_transform as tft
import json
from sklearn.preprocessing import LabelEncoder

LABEL_KEY = "bias"
FEATURE_KEY = "text"
MAX_SEQUENCE_LENGTH = 500  # Set the maximum sequence length

def transformed_name(key):
    """Renaming transformed features"""
    return key + "_xf"
def preprocessing_fn(inputs):
    """
    Preprocess input features into transformed features
    
    Args:
        inputs: map from feature keys to raw features.
    
    Return:
        outputs: map from feature keys to transformed features.    
    """
    
    outputs = {}
    
    # Convert sparse tensor to dense tensor and pad/truncate to fixed length
    dense_tensor = tf.sparse.to_dense(inputs[FEATURE_KEY], default_value='')
    truncated_tensor = tf.strings.substr(dense_tensor, 0, MAX_SEQUENCE_LENGTH)
    
    # Pad the tensor to the fixed length
    padded_tensor = tf.pad(truncated_tensor, [[0, 0], [0, MAX_SEQUENCE_LENGTH - tf.shape(truncated_tensor)[1]]], constant_values=' ')
    
    outputs[transformed_name(FEATURE_KEY)] = tf.strings.lower(padded_tensor)
    
    # Load the mapping from JSON
    with open('mapping.json', 'r') as f:
        mapping = json.load(f)

    # Create a lookup table for the mapping
    initializer = tf.lookup.KeyValueTensorInitializer(
        keys=tf.constant(list(mapping.keys())),
        values=tf.constant(list(mapping.values())),
        key_dtype=tf.string,
        value_dtype=tf.int32
    )
    table = tf.lookup.StaticHashTable(initializer, default_value=-1)
    
    # Convert the label to int32 and then cast to float32
    label_int = table.lookup(inputs[LABEL_KEY])
    outputs[transformed_name(LABEL_KEY)] = tf.cast(label_int, dtype=tf.float32)
    
    # outputs[transformed_name(LABEL_KEY)] = tf.one_hot(inputs[LABEL_KEY], depth=5)
    
    return outputs
