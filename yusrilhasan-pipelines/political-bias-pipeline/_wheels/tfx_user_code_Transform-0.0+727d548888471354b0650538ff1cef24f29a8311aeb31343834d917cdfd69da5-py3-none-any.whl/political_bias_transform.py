import tensorflow as tf
LABEL_KEY = "bias"
FEATURE_KEY = "text"
def transformed_name(key):
    """Renaming transformed features"""
    return key + "_xf"
def preprocessing_fn(inputs):
    """
    Preprocess input features into transformed features
    
    Args:
        inputs: map from feature keys to raw features.
    
    Return:
        outputs: map from feature keys to transformed features.    
    """
    
    outputs = {}
    
    outputs[transformed_name(FEATURE_KEY)] = tf.strings.lower(inputs[FEATURE_KEY])
    
    labels = inputs[LABEL_KEY]
    labels_vocab = tf.unique(tf.reshape(labels, [-1]))[0]
    
    # Create integer indices
    indices = tf.range(tf.size(labels_vocab), dtype=tf.int64)
    
    # Convert both labels and indices to strings before joining
    labels_str = tf.strings.as_string(labels_vocab)
    indices_str = tf.strings.as_string(indices)
    
    # Create mapping strings
    mapping = tf.strings.join([labels_str, indices_str], separator=' -> ')
    
    # Write mapping to file
    tf.io.write_file(
        'label_mapping.txt',
        tf.strings.reduce_join(mapping, separator='\n')
    )
    
    # Create table for encoding
    table = tf.lookup.StaticHashTable(
        tf.lookup.KeyValueTensorInitializer(
            keys=labels_vocab,
            values=indices
        ),
        default_value=-1
    )
    
    outputs[transformed_name(LABEL_KEY)] = table.lookup(labels)
    # outputs[transformed_name(LABEL_KEY)] = tf.one_hot(inputs[LABEL_KEY], depth=5)
    
    return outputs
