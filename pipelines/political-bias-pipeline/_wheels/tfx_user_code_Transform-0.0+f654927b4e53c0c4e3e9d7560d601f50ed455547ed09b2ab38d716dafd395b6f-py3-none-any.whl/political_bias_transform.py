import tensorflow as tf
import tensorflow_transform as tft

LABEL_KEY = "bias"
FEATURE_KEY = "text"
def transformed_name(key):
    """Renaming transformed features"""
    return key + "_xf"
def preprocessing_fn(inputs):
    """
    Preprocess input features into transformed features
    
    Args:
        inputs: map from feature keys to raw features.
    
    Return:
        outputs: map from feature keys to transformed features.    
    """
    
    outputs = {}
    
    outputs[transformed_name(FEATURE_KEY)] = tf.strings.lower(inputs[FEATURE_KEY])
    
    labels = inputs[LABEL_KEY]
    
    # Get unique labels using tft
    labels_vocab = tft.vocabulary.vocabulary(inputs[LABEL_KEY], vocab_filename='labels')
    
    outputs[transformed_name(LABEL_KEY)] = tft.apply_vocabulary(inputs[LABEL_KEY], 
                                                        labels_vocab,
                                                        default_value=-1)
    
    # outputs[transformed_name(LABEL_KEY)] = tf.one_hot(inputs[LABEL_KEY], depth=5)
    
    return outputs
