import tensorflow as tf
import tensorflow_transform as tft

LABEL_KEY = "bias"
FEATURE_KEY = "text"
def transformed_name(key):
    """Renaming transformed features"""
    return key + "_xf"
def preprocessing_fn(inputs):
    """
    Preprocess input features into transformed features
    
    Args:
        inputs: map from feature keys to raw features.
    
    Return:
        outputs: map from feature keys to transformed features.    
    """
    
    outputs = {}
    
    outputs[transformed_name(FEATURE_KEY)] = tf.strings.lower(inputs[FEATURE_KEY])
    
    # Get vocabulary and indices
    labels_vocab, indices = tft.compute_and_apply_vocabulary(
        inputs[LABEL_KEY],
        vocab_filename="labels_vocab_mapped",
        store_frequency=False
    )
    
    # Save mapping using tf.lookup
    table = tf.lookup.StaticHashTable(
        tf.lookup.KeyValueTensorInitializer(
            keys=labels_vocab,
            values=tf.range(tf.size(labels_vocab), dtype=tf.int64)
        ),
        default_value=-1
    )
    
    outputs[transformed_name(LABEL_KEY)] = indices
    
    # outputs[transformed_name(LABEL_KEY)] = tf.one_hot(inputs[LABEL_KEY], depth=5)
    
    return outputs
