import tensorflow as tf
LABEL_KEY = "bias"
FEATURE_KEY = "text"
def preprocessing_fn(inputs):
    # Transform text feature
    text_xf = tf.sparse.to_dense(inputs['text'])
    text_xf = tf.strings.lower(text_xf)
    
    # Transform bias feature
    bias_xf = tf.sparse.to_dense(inputs['bias'])
    bias_xf = tf.strings.lower(bias_xf)
    
    return {
        'text_xf': text_xf,
        'bias_xf': bias_xf
    }
