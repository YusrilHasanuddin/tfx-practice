import tensorflow as tf
LABEL_KEY = "bias"
FEATURE_KEY = "text"
def transformed_name(key):
    """Renaming transformed features"""
    return key + "_xf"
def preprocessing_fn(inputs):
    """
    Preprocess input features into transformed features
    
    Args:
        inputs: map from feature keys to raw features.
    
    Return:
        outputs: map from feature keys to transformed features.    
    """
    
    outputs = {}
    
    outputs[transformed_name(FEATURE_KEY)] = tf.strings.lower(inputs[FEATURE_KEY])
    
    labels = inputs[LABEL_KEY]
    labels_vocab = tf.unique(tf.reshape(labels, [-1]))[0]
    
    # Convert to static values
    labels_vocab_static = tf.keras.layers.StringLookup(
        vocabulary=labels_vocab, num_oov_indices=0
    )
    
    outputs[transformed_name(LABEL_KEY)] = table.lookup(labels)
    # outputs[transformed_name(LABEL_KEY)] = tf.one_hot(inputs[LABEL_KEY], depth=5)
    
    # Save vocabulary for reference
    vocab_filename = 'label_vocab.txt'
    tf.io.write_file(
        vocab_filename,
        tf.strings.reduce_join(labels_vocab, separator='\n')
    )
    
    return outputs
