import tensorflow as tf
import tensorflow_transform as tft
import json
from sklearn.preprocessing import LabelEncoder


LABEL_KEY = "bias"
FEATURE_KEY = "text"
def transformed_name(key):
    """Renaming transformed features"""
    return key + "_xf"
def preprocessing_fn(inputs):
    """
    Preprocess input features into transformed features
    
    Args:
        inputs: map from feature keys to raw features.
    
    Return:
        outputs: map from feature keys to transformed features.    
    """
    
    outputs = {}
    
    outputs[transformed_name(FEATURE_KEY)] = tf.strings.lower(inputs[FEATURE_KEY])
    
    # Load the mapping from JSON
    with open('mapping.json', 'r') as f:
        mapping = json.load(f)

    # Create a lookup table for the mapping
    initializer = tf.lookup.KeyValueTensorInitializer(
        keys=tf.constant(list(mapping.keys())),
        values=tf.constant(list(mapping.values())),
        key_dtype=tf.string,
        value_dtype=tf.int32
    )
    table = tf.lookup.StaticHashTable(initializer, default_value=-1)
    
    outputs[transformed_name(LABEL_KEY)] = table.lookup(inputs[LABEL_KEY])
    
    # outputs[transformed_name(LABEL_KEY)] = tf.one_hot(inputs[LABEL_KEY], depth=5)
    
    return outputs
