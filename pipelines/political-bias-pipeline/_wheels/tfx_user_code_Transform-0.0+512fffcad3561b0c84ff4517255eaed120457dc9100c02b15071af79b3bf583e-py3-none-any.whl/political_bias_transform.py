import tensorflow as tf
LABEL_KEY = "bias"
FEATURE_KEY = "text"
def transformed_name(key):
    """Renaming transformed features"""
    return key + "_xf"
def preprocessing_fn(inputs):
    """
    Preprocess input features into transformed features
    
    Args:
        inputs: map from feature keys to raw features.
    
    Return:
        outputs: map from feature keys to transformed features.    
    """
    
    outputs = {}
    
    outputs[transformed_name(FEATURE_KEY)] = tf.strings.lower(inputs[FEATURE_KEY])
    
    # Ensure the label tensor has the correct shape
    # Get vocabulary from labels
    labels = inputs[LABEL_KEY]
    labels_vocab = tf.unique(tf.reshape(labels, [-1]))[0]
    
    # Create mapping dictionary
    table = tf.lookup.StaticHashTable(
        tf.lookup.KeyValueTensorInitializer(
            keys=labels_vocab,
            values=tf.range(tf.size(labels_vocab), dtype=tf.int64)
        ),
        default_value=-1
    )
    
    # Encode labels
    encoded_labels = table.lookup(labels)
    
    # Save mapping to file
    vocab_filename = 'label_mapping.txt'
    tf.io.write_file(
        vocab_filename,
        tf.strings.reduce_join(
            tf.strings.join([
                labels_vocab,
                tf.strings.as_string(tf.range(tf.size(labels_vocab)))
            ], separator=' -> '),
            separator='\n'
        )
    )
    outputs[transformed_name(LABEL_KEY)] = tf.squeeze(encoded_labels, axis=-2)
    # outputs[transformed_name(LABEL_KEY)] = tf.one_hot(inputs[LABEL_KEY], depth=5)
    
    return outputs
